package com.training;

public class Furniture extends Item{

	public Furniture() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Furniture(String itemName, float itemPrice, int quantity, int duration) {
		super(itemName, itemPrice, quantity, duration);
		// TODO Auto-generated constructor stub
	}

	public Furniture(String itemName, float itemPrice, int quantity) {
		super(itemName, itemPrice, quantity);
		// TODO Auto-generated constructor stub
	}


	
}
