package com.training;

import java.util.*;

public class RentalHandling {
	
	HashSet<Item> itemList;
	public RentalHandling() {
		super();
		itemList = new HashSet(); 
	}
	
	
	
}
