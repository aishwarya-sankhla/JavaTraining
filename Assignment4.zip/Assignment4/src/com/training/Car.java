package com.training;

public class Car extends Item{

	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Car(String itemName, float itemPrice, int quantity, int duration) {
		super(itemName, itemPrice, quantity, duration);
		// TODO Auto-generated constructor stub
	}

	public Car(String itemName, float itemPrice, int quantity) {
		super(itemName, itemPrice, quantity);
		// TODO Auto-generated constructor stub
	}

	
	
}
