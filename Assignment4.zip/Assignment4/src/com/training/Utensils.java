package com.training;

public class Utensils extends Item{

	public Utensils() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Utensils(String itemName, float itemPrice, int quantity, int duration) {
		super(itemName, itemPrice, quantity, duration);
		// TODO Auto-generated constructor stub
	}

	public Utensils(String itemName, float itemPrice, int quantity) {
		super(itemName, itemPrice, quantity);
		// TODO Auto-generated constructor stub
	}


}
